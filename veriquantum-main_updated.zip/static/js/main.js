
document.addEventListener('DOMContentLoaded', function(){
  const t=document.getElementById('menuToggle'); const m=document.getElementById('mobileNav');
  if(t && m){ t.addEventListener('click', ()=> m.classList.toggle('open')); }
});
